# Personal Portfolio Website

## Overview

This is a modern, single-page personal portfolio website built with React, TypeScript, and Tailwind CSS. The application showcases a Site Reliability Engineer's professional profile with sections for About, Projects, and Contact information. It features a clean, responsive design with light/dark mode toggle and smooth scrolling navigation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: Tailwind CSS for utility-first styling
- **Component Library**: Radix UI components via shadcn/ui for accessible, customizable UI components
- **State Management**: React hooks (useState, useContext) for local state and theme management
- **Routing**: Single-page application with smooth scroll navigation between sections

### Backend Architecture
- **Server**: Express.js with TypeScript
- **Database**: PostgreSQL with Neon Database serverless connection
- **ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Express sessions with PostgreSQL store via connect-pg-simple
- **API**: RESTful API structure ready for future expansion

## Key Components

### Frontend Components
- **Portfolio**: Main component containing all sections (hero, about, projects, contact)
- **ThemeProvider**: Context-based theme management for light/dark mode switching
- **UI Components**: Comprehensive set of reusable components (buttons, cards, badges, toast notifications)
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts

### Backend Components
- **Storage Interface**: Abstracted storage layer with in-memory implementation
- **Route Registration**: Modular route handling system
- **Middleware**: Request logging and error handling
- **Development Tools**: Hot module replacement and error overlay for development

## Data Flow

### Frontend Data Flow
1. User interactions trigger state changes through React hooks
2. Theme preferences are persisted to localStorage
3. Contact information can be copied to clipboard with toast feedback
4. Smooth scrolling navigation updates URL anchors

### Backend Data Flow
1. Express middleware handles request logging and parsing
2. Routes are registered through a modular system
3. Storage interface provides CRUD operations (currently in-memory)
4. Error handling middleware catches and formats responses

## External Dependencies

### Frontend Dependencies
- **React Query**: Ready for future API integration
- **Radix UI**: Accessible component primitives
- **Lucide React**: Icon library for consistent iconography
- **class-variance-authority**: Component variant management
- **clsx & tailwind-merge**: Utility for conditional class names

### Backend Dependencies
- **Drizzle ORM**: Type-safe database operations
- **Neon Database**: Serverless PostgreSQL hosting
- **Express Session**: Session management capabilities
- **Zod**: Runtime type validation through drizzle-zod

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with hot module replacement
- **Database**: PostgreSQL connection configured via DATABASE_URL environment variable
- **Asset Handling**: Vite handles static assets and bundling

### Production Build
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Production PostgreSQL database via Neon
- **Migrations**: Drizzle migrations stored in `./migrations` directory

### Architecture Decisions

1. **Monorepo Structure**: Client and server code coexist with shared types in `shared/` directory
2. **TypeScript Throughout**: End-to-end type safety from database to UI
3. **Component-First Design**: Reusable UI components with consistent API
4. **Theme System**: CSS variables enable seamless light/dark mode switching
5. **Accessibility**: Radix UI ensures keyboard navigation and screen reader support
6. **Performance**: Vite's fast bundling and React's efficient rendering
7. **Scalability**: Modular architecture allows easy feature additions

The application is designed as a professional portfolio showcase with the foundation to expand into a full-featured web application with authentication, dynamic content management, and API integrations.